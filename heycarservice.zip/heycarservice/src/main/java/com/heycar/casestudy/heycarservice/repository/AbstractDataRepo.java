package com.heycar.casestudy.heycarservice.repository;

import com.heycar.casestudy.heycarservice.util.StringResources;

public class AbstractDataRepo {
	
	public DataRepo getDataRepo(String filetype) {
		DataRepo dataRepo = null;
		if (StringResources.JSON_FILE.equalsIgnoreCase(filetype)) {
			dataRepo = new JsonDataRepo();
		} /*else if (StringResources.CSV_FILE.equalsIgnoreCase(filetype)) {
			dataRepo = new CsvDataRepo();
		}*/
		return dataRepo;
	}
}
