package com.heycar.casestudy.heycarservice.util;

public final class StringResources {

	public static final String DOT = ".";
	
	//Dealer IDs
	public static final int DEALER_100 = 100;
	public static final int DEALER_200 = 200; 

	//File types
	public static final String JSON_FILE = ".json";
	public static final String CSV_FILE = ".csv"; 
}
