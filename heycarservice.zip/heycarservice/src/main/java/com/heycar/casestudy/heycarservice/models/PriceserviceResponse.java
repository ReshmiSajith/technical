package com.heycar.casestudy.heycarservice.models;

import java.util.Collection;
import java.util.List;

public class PriceserviceResponse {

    private Collection<PartnerPrices> partnersWithPrices;

    public Collection<PartnerPrices> getPartnersWithPrices() {
        return partnersWithPrices;
    }

    public void setPartnersWithPrices(Collection<PartnerPrices> partnersWithPrices) {
        this.partnersWithPrices = partnersWithPrices;
    }
    
    public static class PartnerPrices {

        private int dealerId;
        private List<VehicleDetails> vehicleDetails;
    
        public int getDealerId() {
            return dealerId;
        }
        public void setDealerId(int partnerId) {
            this.dealerId = partnerId;
        }
		public List<VehicleDetails> getVehicleDetails() {
			return vehicleDetails;
		}
		public void setVehicleDetails(List<VehicleDetails> vehicleDetails) {
			this.vehicleDetails = vehicleDetails;
		}
        
    }

    public static class VehicleDetails {
        private int eurocents;
        private String code;
        private String make;
        private String model;
        private int powerInPS;
        private int year;
        private String color;

        public int getEurocents() {
            return eurocents;
        }
        public void setEurocents(int eurocents) {
            this.eurocents = eurocents;
        }
		public String getCode() {
			return code;
		}
		public void setCode(String code) {
			this.code = code;
		}
		public String getMake() {
			return make;
		}
		public void setMake(String make) {
			this.make = make;
		}
		public String getModel() {
			return model;
		}
		public void setModel(String model) {
			this.model = model;
		}
		public int getPowerInPS() {
			return powerInPS;
		}
		public void setPowerInPS(int powerInPS) {
			this.powerInPS = powerInPS;
		}
		public int getYear() {
			return year;
		}
		public void setYear(int year) {
			this.year = year;
		}
		public String getColor() {
			return color;
		}
		public void setColor(String color) {
			this.color = color;
		}
        
    }
}
