package com.heycar.casestudy.heycarservice.repository;

import java.io.File;
import java.io.IOException;

import org.springframework.expression.ParseException;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.heycar.casestudy.heycarservice.dto.BasicDto;
import com.heycar.casestudy.heycarservice.dto.JsonDto;

public interface DataRepo {
	
	BasicDto getAllItemsOfProduct(File fileName) throws JsonParseException, JsonMappingException, IOException, ParseException;
	
	void writeDataToJson(File filename, JsonDto jsonDto) throws JsonGenerationException, JsonMappingException, IOException;
}
