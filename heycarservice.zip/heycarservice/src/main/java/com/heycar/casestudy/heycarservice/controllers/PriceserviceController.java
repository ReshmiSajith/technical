package com.heycar.casestudy.heycarservice.controllers;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.tomcat.util.json.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.heycar.casestudy.heycarservice.models.PriceserviceResponse;
import com.heycar.casestudy.heycarservice.services.PartnerService;
import com.heycar.casestudy.heycarservice.storage.StorageService;
import com.heycar.casestudy.heycarservice.util.StringResources;

@RestController
public class PriceserviceController {
	@Autowired
	RestTemplate restTemplate;
	@Autowired
	ResourceLoader resourceLoader;
	
	private final StorageService storageService;
	@Autowired
	public PriceserviceController(StorageService storageService) {
		this.storageService = storageService;
	}
	
    @GetMapping("/search")
    public PriceserviceResponse getAllPrices() throws JsonParseException, JsonMappingException, IOException, ParseException {
    	System.out.println("in controller");
    	List<File> files = getAllFileNames();
    	PartnerService partnerService = new PartnerService();
    	PriceserviceResponse psResponse = new PriceserviceResponse();
    	for (File file : files) {
    		if (file.getName().contains(String.valueOf(StringResources.DEALER_100))) {    			
    			File filename = getFilePathOfProduct(StringResources.DEALER_100);
    			processServiceResponse(psResponse, partnerService, filename);
    		}
    		if (file.getName().contains(String.valueOf(StringResources.DEALER_200))) {
    			File filename = getFilePathOfProduct(StringResources.DEALER_200);
    			processServiceResponse(psResponse, partnerService, filename);
    		}
    	}
		return psResponse;
    }
    
    private List<File> getAllFileNames() throws IOException {
    	List<File> files = new ArrayList<File>();
    	Resource resource = resourceLoader.getResource("classpath:dealer_100.json");
    	files.add(resource.getFile());
    	resource = resourceLoader.getResource("classpath:dealer_200.json");
    	files.add(resource.getFile());
    	return files;
    }
   
    private File getFilePathOfProduct(int dealerId) throws IOException {
    	File filename = null;
    	Resource resource = null;
    	if (dealerId == 100) {
    		resource = resourceLoader.getResource("classpath:dealer_100.json");
    	} else if (dealerId == 200) {
    		resource = resourceLoader.getResource("classpath:dealer_200.json");
    	}
     	if (resource != null) {
     		filename = resource.getFile();
     	}
        System.out.println(filename);
        return filename;
    }
    
    private File createNewFilePath(int dealerId) throws IOException {
    	File filename = null;
    	Resource resource = null;
    	if (dealerId == 100) {
    		resource = resourceLoader.getResource("classpath:dealer_100.json");
    	} 
     	if (resource != null) {
     		File tempFilename = resource.getFile();
     		filename = new File(tempFilename.getPath()+"dealer_"+dealerId);
     	}
        System.out.println(filename);
        return filename;
    }
    
    @GetMapping("/search/{dealerId}")
    public PriceserviceResponse getAllPricesOfProduct(@PathVariable("dealerId") int dealerId) throws JsonParseException, JsonMappingException, IOException, ParseException {
    	System.out.println("in controller");
    	
    	PartnerService partnerService = new PartnerService();
    	File filename = getFilePathOfProduct(dealerId);
    	PriceserviceResponse psResponse = new PriceserviceResponse();
    	processServiceResponse(psResponse, partnerService, filename);
		return psResponse;
    }
    
    @GetMapping("/search/make={make}")
    public PriceserviceResponse getAllPricesOfProductByMake(@PathVariable("make") String make) throws JsonParseException, JsonMappingException, IOException, ParseException {
    	System.out.println("in controller");
    	
    	List<File> files = getAllFileNames();
    	PartnerService partnerService = new PartnerService();
    	PriceserviceResponse psResponse = new PriceserviceResponse();
    	for (File file : files) {
    		if (file.getName().contains(String.valueOf(StringResources.DEALER_100))) {    			
    			File filename = getFilePathOfProduct(StringResources.DEALER_100);
    			processServiceResponseByMake(psResponse, partnerService, filename, make);
    		}
    		if (file.getName().contains(String.valueOf(StringResources.DEALER_200))) {
    			File filename = getFilePathOfProduct(StringResources.DEALER_200);
    			processServiceResponseByMake(psResponse, partnerService, filename, make);
    		}
    	}
		return psResponse;
    }

	private void processServiceResponse(PriceserviceResponse psResponse, PartnerService partnerService, File filename)
			throws JsonParseException, JsonMappingException, IOException, ParseException {
		partnerService.getAllItemsOfProduct(psResponse, filename);
	}
	
	private void processServiceResponseByMake(PriceserviceResponse psResponse, PartnerService partnerService, File filename, String make)
			throws JsonParseException, JsonMappingException, IOException, ParseException {
		partnerService.getAllItemsOfProductByMake(psResponse, filename, make);
	}
	
	@PostMapping("/vehicle_listings/{dealer_id}/json")
	public PriceserviceResponse saveJsonProduct(@PathVariable("dealerId") int dealerId) 
			throws JsonParseException, JsonMappingException, IOException, ParseException {
    	System.out.println("in controller");
    	
    	PartnerService partnerService = new PartnerService();
    	File filename = getFilePathOfProduct(dealerId);
    	PriceserviceResponse psResponse = new PriceserviceResponse();
    	partnerService.saveServiceRequest(psResponse, filename);
		return psResponse;
    }
	
	@PostMapping("/upload_csv/{dealer_id}/")
	public String handleFileUpload(@RequestParam("file") MultipartFile file, 
			RedirectAttributes redirectAttributes, @PathVariable("dealerId") int dealerId) 
					throws JsonParseException, JsonMappingException, IOException, ParseException {
		storageService.store(file);
		PartnerService partnerService = new PartnerService();
    	PriceserviceResponse psResponse = new PriceserviceResponse();
    	File outputFile = createNewFilePath(dealerId);
    	partnerService.saveCsvServiceRequest(psResponse, file, outputFile);
		return "redirect:/";
	}

}