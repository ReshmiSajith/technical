package com.heycar.casestudy.heycarservice.repository;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.expression.ParseException;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.heycar.casestudy.heycarservice.dto.BasicDto;
import com.heycar.casestudy.heycarservice.dto.JsonData;
import com.heycar.casestudy.heycarservice.dto.JsonDto;

@Repository
public class JsonDataRepo implements DataRepo {

	public BasicDto getAllItemsOfProduct(File fileName) throws JsonParseException, JsonMappingException, IOException, ParseException {
		// read json
		ObjectMapper mapper = new ObjectMapper();
		TypeReference<List<JsonData>> typeReference = new TypeReference<List<JsonData>>(){};
		List<JsonData> jsonDatas =  mapper.readValue(fileName,typeReference);
		System.out.println("Items got!" + jsonDatas.get(0).getCode());
		JsonDto jsonDto = new JsonDto();
		List<JsonDto.Item> items = new ArrayList<JsonDto.Item>();
		for (JsonData jsonData: jsonDatas) {
			JsonDto.Item item = jsonDto.new Item();
			item.setCode(jsonData.getCode());
			item.setColor(jsonData.getColor());
			item.setkW(jsonData.getkW());
			item.setMake(jsonData.getMake());
			item.setModel(jsonData.getModel());
			item.setPrice(jsonData.getPrice());
			item.setYear(jsonData.getYear());
			items.add(item);
		}
		System.out.println(items);
		jsonDto.setItems(items);
		return jsonDto;
	}
	
	
	public void writeDataToJson(File fileName, JsonDto jsonDto) throws JsonGenerationException, JsonMappingException, IOException {
		// write to json
		ObjectMapper mapper = new ObjectMapper();
		mapper.writeValue(fileName, jsonDto);
		System.out.println("Items saved!" + jsonDto);
	}

}
