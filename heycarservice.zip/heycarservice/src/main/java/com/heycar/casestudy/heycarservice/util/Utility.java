package com.heycar.casestudy.heycarservice.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.heycar.casestudy.heycarservice.dto.BasicDto;
import com.heycar.casestudy.heycarservice.dto.JsonDto;
import com.heycar.casestudy.heycarservice.models.PriceserviceResponse;
import com.heycar.casestudy.heycarservice.models.PriceserviceResponse.PartnerPrices;
import com.heycar.casestudy.heycarservice.models.PriceserviceResponse.VehicleDetails;

public class Utility {
	
	public static void populateResponseFromDto (PriceserviceResponse priceServiceResponse, BasicDto basicDto) {
		System.out.println("getPartnersWithPrices before :: " + priceServiceResponse.getPartnersWithPrices());
		if (basicDto != null) {
			if (basicDto instanceof JsonDto) {
				PartnerPrices partnerPrices = new PartnerPrices();
				List<JsonDto.Item> items = ((JsonDto) basicDto).getItems();
				List<VehicleDetails> vehicleDetails = new ArrayList<VehicleDetails>();
				for (JsonDto.Item item : items) {
					VehicleDetails vehicleDet = populateVehicleObject(item);
					vehicleDetails.add(vehicleDet);
				}
				 
				List<PartnerPrices> partnerPricesList = new ArrayList<PartnerPrices>();
				partnerPrices.setDealerId(basicDto.getDealerId());
				partnerPrices.setVehicleDetails(vehicleDetails);
				partnerPricesList.add(partnerPrices);
				priceServiceResponse.setPartnersWithPrices(partnerPricesList);
			}
		}
		System.out.println("getPartnersWithPrices :: " + priceServiceResponse.getPartnersWithPrices());
	}
	
	public static void populateResponseFromDtoByMake (PriceserviceResponse priceServiceResponse, BasicDto basicDto, String make) {
		System.out.println("getPartnersWithPrices before :: " + priceServiceResponse.getPartnersWithPrices());
		if (basicDto != null) {
			if (basicDto instanceof JsonDto) {
				PartnerPrices partnerPrices = new PartnerPrices();
				List<JsonDto.Item> items = ((JsonDto) basicDto).getItems();
				List<VehicleDetails> vehicleDetails = new ArrayList<VehicleDetails>();
				for (JsonDto.Item item : items) {
					if (make.equalsIgnoreCase(item.getMake())) {
						VehicleDetails vehicleDet = populateVehicleObject(item);
						vehicleDetails.add(vehicleDet);
					}
				}
				 
				List<PartnerPrices> partnerPricesList = new ArrayList<PartnerPrices>();
				partnerPrices.setDealerId(basicDto.getDealerId());
				partnerPrices.setVehicleDetails(vehicleDetails);
				partnerPricesList.add(partnerPrices);
				priceServiceResponse.setPartnersWithPrices(partnerPricesList);
			}
		}
		System.out.println("getPartnersWithPrices :: " + priceServiceResponse.getPartnersWithPrices());
	}
	
	public static void populateResponseFromDtoByModel (PriceserviceResponse priceServiceResponse, BasicDto basicDto, String model) {
		System.out.println("getPartnersWithPrices before :: " + priceServiceResponse.getPartnersWithPrices());
		if (basicDto != null) {
			if (basicDto instanceof JsonDto) {
				PartnerPrices partnerPrices = new PartnerPrices();
				List<JsonDto.Item> items = ((JsonDto) basicDto).getItems();
				List<VehicleDetails> vehicleDetails = new ArrayList<VehicleDetails>();
				for (JsonDto.Item item : items) {
					if (model.equalsIgnoreCase(item.getModel())) {
						VehicleDetails vehicleDet = populateVehicleObject(item);
						vehicleDetails.add(vehicleDet);
					}
				}
				 
				List<PartnerPrices> partnerPricesList = new ArrayList<PartnerPrices>();
				partnerPrices.setDealerId(basicDto.getDealerId());
				partnerPrices.setVehicleDetails(vehicleDetails);
				partnerPricesList.add(partnerPrices);
				priceServiceResponse.setPartnersWithPrices(partnerPricesList);
			}
		}
		System.out.println("getPartnersWithPrices :: " + priceServiceResponse.getPartnersWithPrices());
	}
	
	public static void populateResponseFromDtoByYear (PriceserviceResponse priceServiceResponse, BasicDto basicDto, int year) {
		System.out.println("getPartnersWithPrices before :: " + priceServiceResponse.getPartnersWithPrices());
		if (basicDto != null) {
			if (basicDto instanceof JsonDto) {
				PartnerPrices partnerPrices = new PartnerPrices();
				List<JsonDto.Item> items = ((JsonDto) basicDto).getItems();
				List<VehicleDetails> vehicleDetails = new ArrayList<VehicleDetails>();
				for (JsonDto.Item item : items) {
					if (year == item.getYear()) {
						VehicleDetails vehicleDet = populateVehicleObject(item);
						vehicleDetails.add(vehicleDet);
					}
				}
				 
				List<PartnerPrices> partnerPricesList = new ArrayList<PartnerPrices>();
				partnerPrices.setDealerId(basicDto.getDealerId());
				partnerPrices.setVehicleDetails(vehicleDetails);
				partnerPricesList.add(partnerPrices);
				priceServiceResponse.setPartnersWithPrices(partnerPricesList);
			}
		}
		System.out.println("getPartnersWithPrices :: " + priceServiceResponse.getPartnersWithPrices());
	}
	
	public static void populateResponseFromDtoByColor (PriceserviceResponse priceServiceResponse, BasicDto basicDto, String color) {
		System.out.println("getPartnersWithPrices before :: " + priceServiceResponse.getPartnersWithPrices());
		if (basicDto != null) {
			if (basicDto instanceof JsonDto) {
				PartnerPrices partnerPrices = new PartnerPrices();
				List<JsonDto.Item> items = ((JsonDto) basicDto).getItems();
				List<VehicleDetails> vehicleDetails = new ArrayList<VehicleDetails>();
				for (JsonDto.Item item : items) {
					if (color.equalsIgnoreCase(item.getColor())) {
						VehicleDetails vehicleDet = populateVehicleObject(item);
						vehicleDetails.add(vehicleDet);
					}
				}
				 
				List<PartnerPrices> partnerPricesList = new ArrayList<PartnerPrices>();
				partnerPrices.setDealerId(basicDto.getDealerId());
				partnerPrices.setVehicleDetails(vehicleDetails);
				partnerPricesList.add(partnerPrices);
				priceServiceResponse.setPartnersWithPrices(partnerPricesList);
			}
		}
		System.out.println("getPartnersWithPrices :: " + priceServiceResponse.getPartnersWithPrices());
	}

	private static VehicleDetails populateVehicleObject(JsonDto.Item item) {
		VehicleDetails vehicleDet = new VehicleDetails();
		vehicleDet.setCode(item.getCode());
		vehicleDet.setColor(item.getColor());
		vehicleDet.setEurocents(item.getPrice());
		vehicleDet.setMake(item.getMake());
		vehicleDet.setModel(item.getModel());
		vehicleDet.setPowerInPS(item.getkW());
		vehicleDet.setYear(item.getYear());
		return vehicleDet;
	}
	
	public static String getFileType(String filename) {
		String fileType = null;
		if (filename != null && filename.contains(StringResources.DOT)) {
			fileType = filename.substring(filename.lastIndexOf(StringResources.DOT), filename.length());
		}
		return fileType;
	}
	
	public static String getFileName(int productId) throws IOException {
		List<File> filesInFolder = null;
		String fileName = null;
		filesInFolder = Files.walk(Paths.get("resources"))
			        .filter(Files::isRegularFile)
			        .map(Path::toFile)
			        .collect(Collectors.toList());
		if (filesInFolder != null) {			
			for (File file : filesInFolder) {
				if (file.getName().contains("_"+productId)) {
					fileName = file.getName();
				}
			}
		}
		return fileName;
	}
	
	public static JsonDto populateResponseToDto (PriceserviceResponse priceServiceResponse) {
		JsonDto jsonDto = new JsonDto();
		if (priceServiceResponse != null) {
			for (PartnerPrices partnerPrices : priceServiceResponse.getPartnersWithPrices()) {
				jsonDto.setDealerId(partnerPrices.getDealerId());
				List<JsonDto.Item> items = new ArrayList<JsonDto.Item>();
				for (VehicleDetails vehicleDetail: partnerPrices.getVehicleDetails()) {
					JsonDto.Item item = jsonDto.new Item();
					item.setCode(vehicleDetail.getCode());
					item.setColor(vehicleDetail.getColor());
					item.setkW(vehicleDetail.getPowerInPS());
					item.setMake(vehicleDetail.getMake());
					item.setModel(vehicleDetail.getModel());
					item.setPrice(vehicleDetail.getEurocents());
					item.setYear(vehicleDetail.getYear());
					items.add(item);
				}
				jsonDto.setItems(items);
			}
		}
		return jsonDto;
		
	}

}
