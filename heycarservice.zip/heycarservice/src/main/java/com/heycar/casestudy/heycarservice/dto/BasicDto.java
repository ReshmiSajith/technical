package com.heycar.casestudy.heycarservice.dto;

public class BasicDto {
	int dealerId;

	public int getDealerId() {
		return dealerId;
	}

	public void setDealerId(int dealerId) {
		this.dealerId = dealerId;
	}
}
