package com.heycar.casestudy.heycarservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@ComponentScan({ "com.heycar.casestudy.heycarservice",  "controller", "service" })
public class HeycarserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(HeycarserviceApplication.class, args);
	}
	@Bean
   public RestTemplate getRestTemplate() {
      return new RestTemplate();
   }

}
