package com.heycar.casestudy.heycarservice.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.List;
import java.util.Map;

import org.apache.tomcat.util.json.ParseException;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import com.heycar.casestudy.heycarservice.dto.BasicDto;
import com.heycar.casestudy.heycarservice.dto.JsonDto;
import com.heycar.casestudy.heycarservice.models.PriceserviceResponse;
import com.heycar.casestudy.heycarservice.repository.AbstractDataRepo;
import com.heycar.casestudy.heycarservice.repository.DataRepo;
import com.heycar.casestudy.heycarservice.util.Utility;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;

@Service
public class PartnerService {
	
	public void getAllItemsOfProduct(PriceserviceResponse priceserviceResponse, File filename) throws JsonParseException, JsonMappingException, IOException, ParseException {
		AbstractDataRepo abstractDataRepo = new AbstractDataRepo();
		String fileType = Utility.getFileType(filename.getName());
		System.out.println("filename:: " + filename);
		System.out.println("fileType:: " + fileType);
		DataRepo dataRepo = abstractDataRepo.getDataRepo(fileType);
		System.out.println("dataRepo:: " + dataRepo);
		BasicDto basicDto = dataRepo.getAllItemsOfProduct(filename);
		Utility.populateResponseFromDto(priceserviceResponse, basicDto);
	}
	
	public void getAllItemsOfProductByMake(PriceserviceResponse priceserviceResponse, File filename, String make) throws JsonParseException, JsonMappingException, IOException, ParseException {
		AbstractDataRepo abstractDataRepo = new AbstractDataRepo();
		String fileType = Utility.getFileType(filename.getName());
		System.out.println("filename:: " + filename);
		System.out.println("fileType:: " + fileType);
		DataRepo dataRepo = abstractDataRepo.getDataRepo(fileType);
		System.out.println("dataRepo:: " + dataRepo);
		BasicDto basicDto = dataRepo.getAllItemsOfProduct(filename);
		Utility.populateResponseFromDtoByMake(priceserviceResponse, basicDto, make);
	}
	
	public void getAllItemsOfProductByModel(PriceserviceResponse priceserviceResponse, File filename, String model) throws JsonParseException, JsonMappingException, IOException, ParseException {
		AbstractDataRepo abstractDataRepo = new AbstractDataRepo();
		String fileType = Utility.getFileType(filename.getName());
		System.out.println("filename:: " + filename);
		System.out.println("fileType:: " + fileType);
		DataRepo dataRepo = abstractDataRepo.getDataRepo(fileType);
		System.out.println("dataRepo:: " + dataRepo);
		BasicDto basicDto = dataRepo.getAllItemsOfProduct(filename);
		Utility.populateResponseFromDtoByModel(priceserviceResponse, basicDto, model);
	}
	
	public void getAllItemsOfProductByYear(PriceserviceResponse priceserviceResponse, File filename, int year) throws JsonParseException, JsonMappingException, IOException, ParseException {
		AbstractDataRepo abstractDataRepo = new AbstractDataRepo();
		String fileType = Utility.getFileType(filename.getName());
		DataRepo dataRepo = abstractDataRepo.getDataRepo(fileType);
		BasicDto basicDto = dataRepo.getAllItemsOfProduct(filename);
		Utility.populateResponseFromDtoByYear(priceserviceResponse, basicDto, year);
	}
	
	public void getAllItemsOfProductByColor(PriceserviceResponse priceserviceResponse, File filename, String color) throws JsonParseException, JsonMappingException, IOException, ParseException {
		AbstractDataRepo abstractDataRepo = new AbstractDataRepo();
		String fileType = Utility.getFileType(filename.getName());
		DataRepo dataRepo = abstractDataRepo.getDataRepo(fileType);
		BasicDto basicDto = dataRepo.getAllItemsOfProduct(filename);
		Utility.populateResponseFromDtoByColor(priceserviceResponse, basicDto, color);
	}
	public void saveServiceRequest(PriceserviceResponse priceserviceResponse, File filename) throws JsonParseException, JsonMappingException, IOException, ParseException {
		AbstractDataRepo abstractDataRepo = new AbstractDataRepo();
		String fileType = Utility.getFileType(filename.getName());
		DataRepo dataRepo = abstractDataRepo.getDataRepo(fileType);
		JsonDto jsonDto = Utility.populateResponseToDto(priceserviceResponse);
		dataRepo.writeDataToJson(filename, jsonDto);
	}
	
	public void saveCsvServiceRequest(PriceserviceResponse priceserviceResponse, MultipartFile file, File outputFile) throws JsonParseException, JsonMappingException, IOException, ParseException {
		// validate file
        if (file.isEmpty()) {
            return;
        } else {
	        CsvSchema csvSchema = CsvSchema.builder().setUseHeader(true).build();
	        CsvMapper csvMapper = new CsvMapper();
	 
	        // Read data from CSV file
	        List<Object> readAll = csvMapper.readerFor(Map.class).with(csvSchema).readValues(file.getResource().getFile()).readAll();	 
	        ObjectMapper mapper = new ObjectMapper();	 
	        // Write JSON formated data to output file
	        mapper.writerWithDefaultPrettyPrinter().writeValue(outputFile, readAll);

        }
	}
	
}
