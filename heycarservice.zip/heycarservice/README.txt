Assumptions:
1.Save the data only in json format irrespective of the input file format. so that we need to retrieve only json format for all dealers.
2.Technology used - Spring boot with file interaction for storage. due to features on dependency injections and easy to configure plugins and easy to understand
3.use git as version control as it is an open source and easy to use.
4.


If i had more time, i would want to do the following
1.would like to add more junit testcases
2.try to add proper UI. try to run a complete integration test including the client and more file types
3.include exception handling flow, like in case of error, what page to be loaded, with an additional ErrorController
4. try to seperate and categorize the search and save logic in different controllers
4.include caching logic
5. though i have tried to add factory and other design patterns , but still try to add further design patterns with a better design, especially in service layer
6.think about how can a potentially slow REST interface be integrated
7.think about how to scale for multiple thousand requests per second
8.


Frankly mentioning, this challenge is not as simple that can be done in 2 hours :)